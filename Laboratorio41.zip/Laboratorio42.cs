using System;

namespace Laboratorio43
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcion;
            do
            {
                Console.WriteLine("\n--- MENÚ ---");
                Console.WriteLine("1. Saludar");
                Console.WriteLine("2. Despedirse");
                Console.WriteLine("3. Salir");
                Console.Write("Seleccione opción: ");
                opcion = Convert.ToInt32(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("¡Hola!");
                        break;
                    case 2:
                        Console.WriteLine("¡Adiós!");
                        break;
                    case 3:
                        Console.WriteLine("Saliendo...");
                        break;
                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }

            } while (opcion != 3);
        }
    }
}