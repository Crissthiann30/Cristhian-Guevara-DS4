using System;

namespace Laboratorio47
{
    class Program
    {
        // Método con parámetro opcional
        static void Saludar(string nombre = "Usuario")
        {
            Console.WriteLine($"¡Hola, {nombre}!");
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Ejemplo de parámetros opcionales:");

            // Llamada sin argumento (usa valor por defecto)
            Saludar();

            // Llamada con argumento
            Console.Write("Ingrese su nombre: ");
            string nombre = Console.ReadLine();
            Saludar(nombre);
        }
    }
}