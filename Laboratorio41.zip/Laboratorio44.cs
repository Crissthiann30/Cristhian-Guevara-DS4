using System;

namespace Laboratorio45
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5, b = 10, c = 15; // multi-inicialización

            Console.WriteLine($"a = {a}, b = {b}, c = {c}");
            Console.WriteLine($"Suma = {a + b + c}");
        }
    }
}