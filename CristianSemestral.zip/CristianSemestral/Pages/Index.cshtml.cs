using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CristianSemestral.Data;

namespace CristianSemestral.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public int TotalEstudiantes { get; set; }
        public int TotalMaterias { get; set; }
        public int TotalMatriculas { get; set; }
        public int TotalCarreras { get; set; }

        public async Task OnGetAsync()
        {
            // Obtener contadores reales de la DB
            TotalEstudiantes = await _context.Estudiantes.CountAsync();
            TotalMaterias = await _context.Materias.CountAsync();
            TotalMatriculas = await _context.Inscripciones.CountAsync();
            TotalCarreras = await _context.Carreras.CountAsync();
        }
    }
}
