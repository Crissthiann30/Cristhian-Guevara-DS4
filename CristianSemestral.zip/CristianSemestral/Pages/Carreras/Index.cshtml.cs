using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CristianSemestral.Data;
using CristianSemestral.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace CristianSemestral.Pages.Carreras
{
    [Authorize(Roles = "Admin,Profesor")] // Profesores pueden ver, Admin puede editar
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Carrera> Carreras { get; set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Carreras != null)
            {
                Carreras = await _context.Carreras.ToListAsync();
            }
        }
    }
}
