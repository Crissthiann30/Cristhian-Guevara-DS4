using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CristianSemestral.Data;
using CristianSemestral.Models;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CristianSemestral.Pages.Profesores
{
    [Authorize(Roles = "Profesor,Admin")]
    public class PanelModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public PanelModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public Profesor Profesor { get; set; } = default!;
        public IList<Materia> MateriasAsignadas { get; set; } = new List<Materia>();

        public async Task<IActionResult> OnGetAsync()
        {
            // Verificación de seguridad básica
            var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
            if (string.IsNullOrEmpty(userEmail)) return RedirectToPage("/Index");

            // Si es Admin, mostramos todo o quizás un selector (por ahora mostramos todo como si fuera un super-profesor o vacío)
            if (User.IsInRole("Admin"))
            {
               // Lógica especial para Admin: Ver todas las materias con profesor asignado ??
               // Para simplificar, el Admin verá todas las materias
               MateriasAsignadas = await _context.Materias
                   .Include(m => m.Profesor)
                   .ToListAsync();
               return Page();
            }

            // Buscar profesor por correo
            Profesor = await _context.Profesores.FirstOrDefaultAsync(p => p.Correo == userEmail);

            if (Profesor == null)
            {
                // Usuario tiene rol Profesor pero no está en la tabla profesores
                // Esto es un error de datos.
                TempData["Error"] = "No se encontró el perfil de profesor asociado.";
                return RedirectToPage("/Index");
            }

            MateriasAsignadas = await _context.Materias
                .Include(m => m.Profesor)
                .Where(m => m.ProfesorId == Profesor.Id)
                .ToListAsync();

            return Page();
        }
    }
}
