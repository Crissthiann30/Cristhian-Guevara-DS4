#nullable disable
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CristianSemestral.Data;
using CristianSemestral.Models;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CristianSemestral.Pages.Profesores
{
    [Authorize(Roles = "Profesor,Admin")]
    public class CalificarModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public CalificarModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public Materia Materia { get; set; } = default!;
        
        [BindProperty]
        public IList<MatriculaInput> EstudiantesNotas { get; set; } = new List<MatriculaInput>();

        public class MatriculaInput
        {
            public int MatriculaId { get; set; }
            public string? NombreEstudiante { get; set; }
            public string? Cedula { get; set; }
            public decimal? Nota { get; set; }
        }

        public async Task<IActionResult> OnGetAsync(int? materiaId)
        {
            if (materiaId == null) return NotFound();

            Materia = await _context.Materias
                .Include(m => m.Profesor)
                .FirstOrDefaultAsync(m => m.Id == materiaId);

            if (Materia == null) return NotFound();

            // Validar que sea el profesor asignado (o Admin)
            var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
            if (!User.IsInRole("Admin") && (Materia.Profesor == null || Materia.Profesor.Correo != userEmail))
            {
                return Forbid();
            }

            var inscripciones = await _context.Inscripciones
                .Include(i => i.Estudiante)
                .Where(i => i.MateriaId == materiaId)
                .ToListAsync();

            EstudiantesNotas = inscripciones.Select(i => new MatriculaInput
            {
                MatriculaId = i.Id,
                NombreEstudiante = i.Estudiante?.NombreCompleto ?? "Desconocido",
                Cedula = i.Estudiante?.Cedula ?? "N/A",
                Nota = i.Nota
            }).ToList();

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? materiaId)
        {
            if (materiaId == null) return NotFound();

            // Recargar materia para info visual si hay error, o redirección
            Materia = await _context.Materias.FindAsync(materiaId);

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Error en los datos. Verifique el formato de la nota (use '.' o ',' según su configuración).";
                return Page();
            }

            foreach (var item in EstudiantesNotas)
            {
                var matricula = await _context.Inscripciones.FindAsync(item.MatriculaId);
                if (matricula != null)
                {
                    matricula.Nota = item.Nota;
                    
                    // Lógica Automática de Estado
                    if (item.Nota.HasValue)
                    {
                        if (item.Nota >= 71) matricula.EstadoStr = "Completada"; // Aprobado
                        else matricula.EstadoStr = "Reprobada";
                    }
                    else
                    {
                         matricula.EstadoStr = "Activa"; // Sin nota
                    }
                }
            }

            await _context.SaveChangesAsync();
            TempData["Success"] = "Notas guardadas correctamente.";
            
            return RedirectToPage(new { materiaId = materiaId });
        }
    }
}
