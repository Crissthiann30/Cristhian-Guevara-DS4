#nullable disable
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CristianSemestral.Models;
using CristianSemestral.Data;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace CristianSemestral.Pages.Matriculas
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Matricula> Matriculas { get; set; } = new List<Matricula>();

        [BindProperty(SupportsGet = true)]
        public string SearchString { get; set; }

        public async Task OnGetAsync()
        {
            var query = _context.Inscripciones
                .Include(m => m.Estudiante)
                .Include(m => m.Materia)
                .AsQueryable();

            // 🔐 Filtro por estudiante
            if (User.IsInRole("Estudiante"))
            {
                var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;

                if (!string.IsNullOrWhiteSpace(userEmail))
                {
                    query = query.Where(m =>
                        m.Estudiante != null &&
                        m.Estudiante.Correo == userEmail
                    );
                }
            }

            // 🔍 Filtro de búsqueda seguro (ANTI NULL)
            if (!string.IsNullOrWhiteSpace(SearchString))
            {
                query = query.Where(m =>
                    (m.Estudiante != null &&
                        (
                            (m.Estudiante.Nombre ?? "").Contains(SearchString) ||
                            (m.Estudiante.Apellido ?? "").Contains(SearchString) ||
                            (m.Estudiante.Cedula ?? "").Contains(SearchString)
                        )
                    )
                    ||
                    (m.Materia != null &&
                        (
                            (m.Materia.Nombre ?? "").Contains(SearchString) ||
                            (m.Materia.Codigo ?? "").Contains(SearchString)
                        )
                    )
                );
            }

            Matriculas = await query.ToListAsync();
        }
    }
}
