using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CristianSemestral.Data;
using CristianSemestral.Models;
using System.Threading.Tasks;

namespace CristianSemestral.Pages.Matriculas
{
    public class DeleteModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public DeleteModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Matricula Matricula { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Inscripciones == null)
            {
                return NotFound();
            }

            var matricula = await _context.Inscripciones
                .Include(m => m.Estudiante)
                .Include(m => m.Materia)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (matricula == null)
            {
                return NotFound();
            }
            else 
            {
                Matricula = matricula;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.Inscripciones == null)
            {
                return NotFound();
            }
            var matricula = await _context.Inscripciones
                                .Include(m => m.Materia)
                                .Include(m => m.Estudiante)
                                .FirstOrDefaultAsync(m => m.Id == id);

            if (matricula != null)
            {
                Matricula = matricula;

                // Devolver créditos al estudiante (Lógica inversa a Create)
                if (Matricula.Estudiante != null && Matricula.Materia != null)
                {
                    Matricula.Estudiante.CreditosDisponibles += Matricula.Materia.Creditos;
                    _context.Update(Matricula.Estudiante);
                }

                _context.Inscripciones.Remove(Matricula);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
