using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using CristianSemestral.Data;
using CristianSemestral.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

namespace CristianSemestral.Pages.Matriculas
{
    [Authorize]
    public class CreateModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public CreateModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet(int? materiaId)
        {
            ViewData["EstudianteId"] = new SelectList(new List<object>(), "Id", "NombreCompleto");
            var materiasQuery = _context.Materias.AsQueryable();

            if (User.IsInRole("Estudiante"))
            {
                var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
                var estudiante = _context.Estudiantes.FirstOrDefault(e => e.Correo == userEmail);
                if (estudiante != null)
                {
                    ViewData["EstudianteId"] = new SelectList(new[] { estudiante }, "Id", "NombreCompleto", estudiante.Id);
                    ViewData["IsStudent"] = true;
                    // Filtrar materias por carrera del estudiante
                    materiasQuery = materiasQuery.Where(m => m.CarreraId == estudiante.CarreraId);
                    
                    // IMPORTANTE: Pre-asignar el ID al modelo para que el campo oculto tenga valor
                    Matricula = new Matricula { EstudianteId = estudiante.Id };
                }
                else
                {
                    ViewData["Error"] = "No se encontró un perfil de estudiante asociado a este usuario.";
                    ViewData["IsStudent"] = true; 
                    return Page(); 
                }
            }
            else
            {
                 ViewData["EstudianteId"] = new SelectList(_context.Estudiantes.Select(e => new { Id = e.Id, NombreCompleto = e.Nombre + " " + e.Apellido }), "Id", "NombreCompleto");
                 ViewData["IsStudent"] = false;
            }

            ViewData["MateriaId"] = new SelectList(materiasQuery, "Id", "Nombre", materiaId);
            return Page();
        }

        [BindProperty]
        public Matricula Matricula { get; set; } = default!;

        public async Task<IActionResult> OnPostAsync()
        {
            // Lógica de seguridad: Si es estudiante, FORZAR su ID (ignorar lo que venga del form por seguridad)
            if (User.IsInRole("Estudiante"))
            {
                var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
                var estudiante = _context.Estudiantes.FirstOrDefault(e => e.Correo == userEmail);
                if (estudiante != null)
                {
                    Matricula.EstudianteId = estudiante.Id; // Override
                    ModelState.Remove("Matricula.EstudianteId"); // Limpiar validación previa si falló por ser 0
                }
            }

            if (!ModelState.IsValid)
            {
                // Recargar listas y Estado IsStudent si falla
                var materiasQuery = _context.Materias.AsQueryable();
                
                if (User.IsInRole("Estudiante"))
                {
                    ViewData["IsStudent"] = true;
                    var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
                    var estudiante = _context.Estudiantes.FirstOrDefault(e => e.Correo == userEmail);
                     if (estudiante != null)
                     {
                        materiasQuery = materiasQuery.Where(m => m.CarreraId == estudiante.CarreraId);
                        ViewData["EstudianteId"] = new SelectList(new[] { estudiante }, "Id", "NombreCompleto", estudiante.Id);
                     }
                }
                else
                {
                     ViewData["IsStudent"] = false;
                     ViewData["EstudianteId"] = new SelectList(_context.Estudiantes.Select(e => new { Id = e.Id, NombreCompleto = e.Nombre + " " + e.Apellido }), "Id", "NombreCompleto");
                }

                 ViewData["MateriaId"] = new SelectList(materiasQuery, "Id", "Nombre");
                return Page();
            }

            // Validar que no esté ya inscrito
            bool existe = await _context.Inscripciones.AnyAsync(m => 
                m.EstudianteId == Matricula.EstudianteId && 
                m.MateriaId == Matricula.MateriaId);

            if (existe)
            {
                ModelState.AddModelError("", "El estudiante ya está inscrito en esta materia.");
                // Recarga de listas
                var materiasQuery = _context.Materias.AsQueryable();
                if (User.IsInRole("Estudiante"))
                {
                    ViewData["IsStudent"] = true;
                    var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
                    var estudiante = _context.Estudiantes.FirstOrDefault(e => e.Correo == userEmail);
                     if (estudiante != null)
                     {
                        materiasQuery = materiasQuery.Where(m => m.CarreraId == estudiante.CarreraId);
                        ViewData["EstudianteId"] = new SelectList(new[] { estudiante }, "Id", "NombreCompleto", estudiante.Id);
                     }
                }
                else
                {
                     ViewData["IsStudent"] = false;
                     ViewData["EstudianteId"] = new SelectList(_context.Estudiantes.Select(e => new { Id = e.Id, NombreCompleto = e.Nombre + " " + e.Apellido }), "Id", "NombreCompleto");
                }
                 ViewData["MateriaId"] = new SelectList(materiasQuery, "Id", "Nombre");
                return Page();
            }

            // --- NUEVA LÓGICA DE CRÉDITOS ---
            var materia = await _context.Materias.FindAsync(Matricula.MateriaId);
            var alumno = await _context.Estudiantes.FindAsync(Matricula.EstudianteId);

            if (materia != null && alumno != null)
            {
                if (alumno.CreditosDisponibles >= materia.Creditos)
                {
                    alumno.CreditosDisponibles -= materia.Creditos;
                    _context.Update(alumno); // Guardar el descuento
                }
                else
                {
                    ModelState.AddModelError("", $"Créditos insuficientes. Disponibles: {alumno.CreditosDisponibles}, Requeridos: {materia.Creditos}");
                    // Recargar listas (Código duplicado, idealmente refactorizar)
                    var materiasQuery = _context.Materias.AsQueryable();
                    if (User.IsInRole("Estudiante"))
                    {
                        ViewData["IsStudent"] = true;
                        var estudianteObj = _context.Estudiantes.FirstOrDefault(e => e.Id == Matricula.EstudianteId);
                        if (estudianteObj != null)
                        {
                            materiasQuery = materiasQuery.Where(m => m.CarreraId == estudianteObj.CarreraId);
                            ViewData["EstudianteId"] = new SelectList(new[] { estudianteObj }, "Id", "NombreCompleto", estudianteObj.Id);
                        }
                    }
                    else
                    {
                        ViewData["MateriaId"] = new SelectList(_context.Materias, "Id", "Nombre");
                        ViewData["EstudianteId"] = new SelectList(_context.Estudiantes.Select(e => new { Id = e.Id, NombreCompleto = e.Nombre + " " + e.Apellido }), "Id", "NombreCompleto");
                    }
                     ViewData["MateriaId"] = new SelectList(materiasQuery, "Id", "Nombre");
                    return Page();
                }
            }
            // --------------------------------

            _context.Inscripciones.Add(Matricula);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
