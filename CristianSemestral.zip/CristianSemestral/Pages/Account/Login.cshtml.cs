using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using CristianSemestral.Data;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace CristianSemestral.Pages.Account
{
    public class LoginModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public LoginModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        [Required(ErrorMessage = "El correo es requerido")]
        [EmailAddress(ErrorMessage = "Correo inválido")]
        public string Correo { get; set; } = default!;

        [BindProperty]
        [Required(ErrorMessage = "La contraseña es requerida")]
        public string Password { get; set; } = default!;

        public string? ErrorMessage { get; set; } // Permitir nulo

        public async Task<IActionResult> OnGetAsync()
        {
            // Si ya está logueado, redirigir al inicio
            if (User.Identity != null && User.Identity.IsAuthenticated)
            {
                return RedirectToPage("/Index");
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Buscar usuario
            var user = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.Correo == Correo);

            // Verificar si usuario existe y si la contraseña coincide (Hash o Texto Plano por compatibilidad legacy)
            bool isValid = false;
            if (user != null)
            {
                // Intento 1: Verificar Hash
                if (Utilities.PasswordService.VerifyPassword(Password, user.Password))
                {
                    isValid = true;
                }
                // Intento 2: Verificar Texto Plano (para usuarios viejos o si no se migró)
                else if (user.Password == Password)
                {
                    // Opcional: Migrar a hash automáticamente
                    isValid = true;
                }
            }

            if (!isValid || user == null)
            {
                ErrorMessage = "Credenciales inválidas. Intente de nuevo.";
                return Page();
            }

            if (user == null)
            {
                ErrorMessage = "Credenciales inválidas. Intente de nuevo.";
                return Page();
            }

            // Crear Claims (Información de sesión)
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Nombre),
                new Claim(ClaimTypes.Email, user.Correo),
                new Claim(ClaimTypes.Role, user.Rol ?? "User"),
                new Claim("UserId", user.Id.ToString())
            };

            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var authProperties = new AuthenticationProperties
            {
                IsPersistent = true, // Mantener sesión "Recordarme"
                ExpiresUtc = DateTime.UtcNow.AddHours(8)
            };

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                authProperties);

            return RedirectToPage("/Index");
        }
    }
}
