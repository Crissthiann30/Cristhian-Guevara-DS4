using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CristianSemestral.Models;
using CristianSemestral.Data;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CristianSemestral.Pages.Materias
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Materia> Materias { get; set; } = default!;
        public HashSet<int> MateriasInscritas { get; set; } = new HashSet<int>();
        public int? CarreraEstudianteId { get; set; }
        public int CreditosDisponibles { get; set; }

        public async Task OnGetAsync()
        {
            if (_context.Materias != null)
            {
                Materias = await _context.Materias.Include(m => m.Profesor).ToListAsync();

                if (User.IsInRole("Estudiante"))
                {
                    var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
                    if (!string.IsNullOrEmpty(userEmail))
                    {
                        var estudiante = await _context.Estudiantes.FirstOrDefaultAsync(e => e.Correo == userEmail);
                        if (estudiante != null)
                        {
                            CarreraEstudianteId = estudiante.CarreraId;
                            CreditosDisponibles = estudiante.CreditosDisponibles;
                            MateriasInscritas = (await _context.Inscripciones
                                .Where(i => i.EstudianteId == estudiante.Id)
                                .Select(i => i.MateriaId)
                                .ToListAsync())
                                .ToHashSet();
                        }
                    }
                }
            }
        }
    }
}
