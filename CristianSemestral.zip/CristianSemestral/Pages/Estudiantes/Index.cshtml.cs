using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CristianSemestral.Models;
using CristianSemestral.Data;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CristianSemestral.Pages.Estudiantes
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Estudiante> Estudiantes { get; set; } = default!;

        public async Task OnGetAsync()
        {
            var query = _context.Estudiantes
                .Include(e => e.Carrera)
                .AsQueryable();

            // Lógica de "Compañeros de Clase"
            if (User.IsInRole("Estudiante"))
            {
                var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
                // Buscar al estudiante logueado para saber su carrera
                var me = await _context.Estudiantes.FirstOrDefaultAsync(e => e.Correo == userEmail);
                
                if (me != null)
                {
                    // Filtrar: Solo mostrar estudiantes de MI carrera
                    query = query.Where(e => e.CarreraId == me.CarreraId);
                }
            }

            Estudiantes = await query.ToListAsync();


        }
    }
}
