using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using CristianSemestral.Models;
using CristianSemestral.Data;
using System.Threading.Tasks;

namespace CristianSemestral.Pages.Estudiantes
{
    public class CreateModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public CreateModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            if (User.IsInRole("Estudiante"))
            {
                return RedirectToPage("/Index");
            }
            ViewData["CarreraId"] = new SelectList(_context.Carreras, "Id", "Nombre");
            return Page();
        }

        [BindProperty]
        public Estudiante Estudiante { get; set; } = default!;

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                // Temporal: Asignar un valor por defecto a CarreraId si viene 0, para pruebas
                // Idealmente cargaríamos las carreras reales de la DB
                if(Estudiante.CarreraId == 0) Estudiante.CarreraId = 1; 

                // Re-validar tras asignar defaults si fuera necesario, o ignorar errores específicos
                // return Page(); 
            }
            
            // Forzar ID 1 si es 0 por ahora para evitar error de FK si existe constraint
            if(Estudiante.CarreraId == 0) Estudiante.CarreraId = 1; 
            
            // Asegurar fecha registro
            Estudiante.FechaRegistro = DateTime.Now;

            _context.Estudiantes.Add(Estudiante);
            await _context.SaveChangesAsync();

            // Retornar a Index, idealmente deberíamos manejar si es AJAX para actualizar solo la sección,
            // pero la redirección estándar funciona para recargar.
            return RedirectToPage("./Index");
        }
    }
}
