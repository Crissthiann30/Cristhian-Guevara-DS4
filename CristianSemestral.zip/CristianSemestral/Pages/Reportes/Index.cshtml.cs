using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using CristianSemestral.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CristianSemestral.Models;

namespace CristianSemestral.Pages.Reportes
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public class ReporteCarrera
        {
            public string Nombre { get; set; } = string.Empty;
            public int CantidadEstudiantes { get; set; }
        }

        public class ReporteMateria
        {
            public string Nombre { get; set; } = string.Empty;
            public int CantidadInscritos { get; set; }
        }

        // Propiedades para Admin
        public List<ReporteCarrera> EstudiantesPorCarrera { get; set; } = new List<ReporteCarrera>();
        public List<ReporteMateria> MateriasPopulares { get; set; } = new List<ReporteMateria>();

        // Propiedades para Estudiante
        public int MateriasAprobadas { get; set; }
        public int CreditosAcumulados { get; set; }
        public string PromedioGeneral { get; set; } = "N/A";
        public IList<Matricula> HistorialAcademico { get; set; } = new List<Matricula>();

        public async Task OnGetAsync()
        {
            if (User.IsInRole("Estudiante"))
            {
                var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
                if (!string.IsNullOrEmpty(userEmail))
                {
                    var estudiante = await _context.Estudiantes.FirstOrDefaultAsync(e => e.Correo == userEmail);
                    if (estudiante != null)
                    {
                        HistorialAcademico = await _context.Inscripciones
                            .Include(m => m.Materia)
                            .Where(m => m.EstudianteId == estudiante.Id)
                            .OrderByDescending(m => m.FechaMatricula)
                            .ToListAsync();

                        var materiasConNota = HistorialAcademico.Where(m => m.Nota.HasValue).ToList();
                        
                        if (materiasConNota.Any())
                        {
                            MateriasAprobadas = materiasConNota.Count(m => m.Nota >= 71);
                            CreditosAcumulados = materiasConNota
                                .Where(m => m.Nota >= 71)
                                .Sum(m => m.Materia?.Creditos ?? 0);
                            
                            double promedio = (double)materiasConNota.Average(m => m.Nota!.Value);
                            PromedioGeneral = promedio.ToString("0.00");
                        }
                    }
                }
            }
            else
            {
                // Lógica de Admin (Solo cargar si NO es estudiante para ahorrar recursos, o ambos si se requiere)
                // Reporte 1: Estudiantes por Carrera
                EstudiantesPorCarrera = await _context.Carreras
                    .Select(c => new ReporteCarrera
                    {
                        Nombre = c.Nombre,
                        CantidadEstudiantes = _context.Estudiantes.Count(e => e.CarreraId == c.Id)
                    })
                    .ToListAsync();

                // Reporte 2: Materias con más inscritos
                MateriasPopulares = await _context.Materias
                    .Select(m => new ReporteMateria
                    {
                        Nombre = m.Nombre,
                        CantidadInscritos = _context.Inscripciones.Count(i => i.MateriaId == m.Id)
                    })
                    .OrderByDescending(x => x.CantidadInscritos)
                    .Take(5)
                    .ToListAsync();
            }
        }
    }
}
