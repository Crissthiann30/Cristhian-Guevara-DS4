using Microsoft.AspNetCore.Mvc.RazorPages;
using CristianSemestral.Models;
using CristianSemestral.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System;
using System;
using System.Threading.Tasks;
using System.Linq;

namespace CristianSemestral.Pages.Calendario
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<EventoCalendario> ProximosEventos { get; set; } = new List<EventoCalendario>();

        public async Task OnGetAsync()
        {
            // 1. Eventos automáticos (Inscripciones)
            var inscripciones = await _context.Inscripciones
                .Include(i => i.Estudiante)
                .Include(i => i.Materia)
                .OrderByDescending(i => i.FechaMatricula)
                .Take(5)
                .ToListAsync();

            foreach(var item in inscripciones)
            {
                ProximosEventos.Add(new EventoCalendario
                {
                    Id = item.Id,
                    Titulo = item.Materia != null ? $"Inscripción: {item.Materia.Nombre}" : "Inscripción",
                    Descripcion = $"Estado: {item.EstadoStr}",
                    FechaInicio = item.FechaMatricula,
                    FechaFin = item.FechaMatricula.AddHours(1),
                    Tipo = "Inscripción",
                    ColorClase = "info"
                });
            }

            // 2. Eventos Manuales (Base de Datos)
            if (User.Identity.IsAuthenticated)
            {
                var userEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value;
                if (!string.IsNullOrEmpty(userEmail))
                {
                    var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.Correo == userEmail);
                    if (usuario != null)
                    {
                        var misEventos = await _context.Eventos
                            .Where(e => e.UsuarioId == usuario.Id || e.UsuarioId == null) // Míos + Públicos
                            .OrderBy(e => e.FechaInicio)
                            .ToListAsync();

                        foreach(var ev in misEventos)
                        {
                            ProximosEventos.Add(new EventoCalendario
                            {
                                Id = ev.Id,
                                Titulo = ev.Titulo,
                                Descripcion = ev.Descripcion ?? "",
                                FechaInicio = ev.FechaInicio,
                                FechaFin = ev.FechaFin,
                                Tipo = ev.Tipo,
                                ColorClase = ev.Color // Usar color guardado
                            });
                        }
                    }
                }
            }

            // Ordenar todos cronológicamente
            ProximosEventos = ProximosEventos.OrderBy(e => e.FechaInicio).ToList();
        }
    }
}
