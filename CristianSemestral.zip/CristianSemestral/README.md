# Sistema de Gestión Académica

Este proyecto es una aplicación web robusta construida con **ASP.NET Core**, diseñada para la gestión de estudiantes, profesores, materias y calificaciones.

## 🏗️ Arquitectura Técnica

La aplicación utiliza el patrón **Razor Pages**, que es la evolución moderna del patrón **MVC (Modelo-Vista-Controlador)** recomendado por Microsoft para aplicaciones web centradas en páginas.

### ¿Cómo se aplica MVC aquí?
Aunque no veas la carpeta `Controllers` clásica, los principios MVC se respetan estrictamente:

1.  **Model (Modelo):** 
    *   Ubicación: `/Models` (ej: `Estudiante.cs`, `Materia.cs`).
    *   Función: Define la estructura de los datos y las reglas de negocio base.
2.  **View (Vista):** 
    *   Ubicación: `/Pages/*.cshtml` (ej: `Calificar.cshtml`).
    *   Función: Es la interfaz de usuario (HTML + Razor) que ve el usuario final.
3.  **Controller (Controlador/Lógica):** 
    *   Ubicación: `/Pages/*.cshtml.cs` (ej: `Calificar.cshtml.cs`).
    *   Función: Conocidos como **PageModels**, manejan la lógica de cada página. Reciben la petición, procesan datos con la BD y deciden qué mostrar.

---

## 🚀 El Servidor Web: Kestrel

A diferencia de tecnologías antiguas (como PHP clásico que requiere Apache), esta aplicación es **autocontenida**.

*   **Kestrel:** Es el servidor web cross-platform incluido dentro de tu aplicación `dotnet`.
*   **Funcionamiento:** Cuando ejecutas `dotnet run`, Kestrel se inicia, abre el puerto (usualmente 5xxx) y comienza a escuchar peticiones HTTP directamente. Es extremadamente rápido y ligero.

---

## 🧠 El Cerebro: Program.cs y el Pipeline

El archivo `Program.cs` es donde todo comienza. Funciona como una **tubería de procesamiento (Pipeline)**. Cuando llega una petición del navegador, pasa por una serie de "filtros" (Middlewares) en orden:

1.  **Archivos Estáticos:** (`UseStaticFiles`) Si piden una imagen o CSS, se entrega aquí.
2.  **Enrutamiento:** (`UseRouting`) El servidor decide qué página ejecutar basándose en la URL.
3.  **Localización:** (`UseRequestLocalization`) Ajusta el formato de números/fechas (ej: decimales con punto).
4.  **Autenticación:** (`UseAuthentication`) ¿Quién es el usuario? (Lee la Cookie segura).
5.  **Autorización:** (`UseAuthorization`) ¿Tiene permiso el usuario? (Verifica el Rol).
6.  **Endpoints:** (`MapRazorPages`) Finalmente, ejecuta el código de la página solicitada.

---

## 🔄 Flujo de Vida de una Petición

Ejemplo: Un profesor califica a un estudiante.

1.  **Request (Petición):** El navegador envía `POST /Calificar` con la nota "100".
2.  **PageModel (C#):** El método `OnPostAsync` en `Calificar.cshtml.cs` recibe el dato.
3.  **Validación y BD:** 
    *   Se valida que sea un número correcto.
    *   Se usa **Entity Framework Core** (`_context`) para guardar en MySQL.
4.  **Respuesta:** El servidor genera el HTML actualizado con el mensaje "Guardado" y lo envía de vuelta.

---

## 📂 Estructura del Proyecto

*   `Pages/`: Contiene todas las rutas y vistas del sistema.
*   `Models/`: Clases que representan las tablas de la BD.
*   `Data/`: Contexto de base de datos (conexión MySQL).
*   `wwwroot/`: Archivos públicos (CSS, JS, Imágenes).
*   `Utilities/`: Servicios auxiliares (ej: Hashing de contraseñas).
