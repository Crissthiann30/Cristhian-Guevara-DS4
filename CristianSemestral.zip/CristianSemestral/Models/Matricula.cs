using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CristianSemestral.Models
{
    [Table("inscripciones")]
    public class Matricula
    {
        [Key]
        [Column("ID")]
        public int Id { get; set; }

        [Column("EstudianteID")]
        public int EstudianteId { get; set; }
        
        [ForeignKey("EstudianteId")]
        public Estudiante? Estudiante { get; set; }

        [Column("MateriaID")]
        public int MateriaId { get; set; }

        [ForeignKey("MateriaId")]
        public Materia? Materia { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Fecha de Inscripción")]
        [Column("FechaInscripcion")]
        public DateTime FechaMatricula { get; set; } = DateTime.Now;

        // Mapearemos esto como string en el DbContext porque en DB es VARCHAR(20)
        [Column("Nota")]
        [Range(0, 100, ErrorMessage = "La nota debe estar entre 0 y 100")]
        public decimal? Nota { get; set; }

        [Column("Estado")]
        public string EstadoStr { get; set; } = "Activa";

        [NotMapped]
        public EstadoMatricula Estado 
        { 
            get => Enum.TryParse(EstadoStr, true, out EstadoMatricula result) ? result : EstadoMatricula.Activa;
            set => EstadoStr = value.ToString();
        }

        // Propiedades auxiliares
        [NotMapped]
        public string Periodo { get; set; } = "2025-1";
    }

    public enum EstadoMatricula
    {
        Activa,
        Completada,
        Retirada,
        Reprobada
    }
}
