using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CristianSemestral.Models
{
    [Table("eventos")]
    public class Evento
    {
        [Key]
        [Column("ID")]
        public int Id { get; set; }

        [Required(ErrorMessage = "El título es obligatorio")]
        public string Titulo { get; set; } = string.Empty;

        public string? Descripcion { get; set; }

        [Required]
        [Display(Name = "Inicio")]
        public DateTime FechaInicio { get; set; } = DateTime.Now;

        [Required]
        [Display(Name = "Fin")]
        public DateTime FechaFin { get; set; } = DateTime.Now.AddHours(1);

        public string Tipo { get; set; } = "Personal"; 

        [Column("UsuarioID")]
        public int? UsuarioId { get; set; } // Nullable para eventos globales

        public string Color { get; set; } = "primary"; // primary, danger, success, warning, info
    }
}
