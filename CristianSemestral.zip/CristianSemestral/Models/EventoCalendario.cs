using System;

namespace CristianSemestral.Models
{
    public class EventoCalendario
    {
        public int Id { get; set; }
        public string Titulo { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin { get; set; }
        public string Tipo { get; set; } = "General"; // Examen, Clase, Feriado, etc.
        public string ColorClase { get; set; } = "primary"; // Bootstrap color class
    }
}
