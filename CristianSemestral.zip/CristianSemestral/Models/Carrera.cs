using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CristianSemestral.Models
{
    [Table("carreras")]
    public class Carrera
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Required]
        [Column("nombre")]
        public string Nombre { get; set; } = string.Empty;

        [Column("decano")]
        public string? Decano { get; set; }
    }
}
