using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CristianSemestral.Models
{
    [Table("materias")]
    public class Materia
    {
        [Key]
        [Column("ID")]
        public int Id { get; set; }

        [Required(ErrorMessage = "El código es obligatorio")]
        public string Codigo { get; set; } = string.Empty;

        [Required(ErrorMessage = "El nombre de la materia es obligatorio")]
        public string Nombre { get; set; } = string.Empty;

        public string? Descripcion { get; set; }

        [Required]
        [Display(Name = "Créditos")]
        [Range(1, 10, ErrorMessage = "Los créditos deben estar entre 1 y 10")]
        public int Creditos { get; set; }

        [Column("CarreraID")]
        public int? CarreraId { get; set; }

        [Column("ProfesorID")]
        public int? ProfesorId { get; set; }

        [ForeignKey("ProfesorId")]
        public Profesor? Profesor { get; set; }

        [Column("FechaCreacion")]
        public DateTime FechaCreacion { get; set; } = DateTime.Now;

        [NotMapped]
        public string Horario { get; set; } = string.Empty;
    }
}
