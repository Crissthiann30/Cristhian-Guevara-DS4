USE `estudiantes_db`;

-- 1. Crear tabla Profesores si no existe
CREATE TABLE IF NOT EXISTS `profesores` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `Cedula` varchar(20) NOT NULL,
  `Correo` varchar(100) NOT NULL,
  `Especialidad` varchar(100) DEFAULT NULL,
  `FechaRegistro` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Cedula` (`Cedula`),
  UNIQUE KEY `Correo` (`Correo`)
) ENGINE=InnoDB;

-- 2. Asegurar que la tabla inscripciones tenga la columna Nota
-- Generamos un procedimiento almacenado temporal para verificar la columna
DROP PROCEDURE IF EXISTS AddNotaColumn;
DELIMITER //
CREATE PROCEDURE AddNotaColumn()
BEGIN
    IF NOT EXISTS (
        SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'inscripciones' 
        AND COLUMN_NAME = 'Nota'
    ) THEN
        ALTER TABLE `inscripciones` ADD COLUMN `Nota` decimal(4,2) DEFAULT NULL;
    END IF;
END //
DELIMITER ;
CALL AddNotaColumn();
DROP PROCEDURE AddNotaColumn;

-- 3. Asegurar columnas en Materias (ProfesorID)
DROP PROCEDURE IF EXISTS AddProfesorColumn;
DELIMITER //
CREATE PROCEDURE AddProfesorColumn()
BEGIN
    IF NOT EXISTS (
        SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'materias' 
        AND COLUMN_NAME = 'ProfesorID'
    ) THEN
        ALTER TABLE `materias` ADD COLUMN `ProfesorID` int DEFAULT NULL;
    END IF;
END //
DELIMITER ;
CALL AddProfesorColumn();
DROP PROCEDURE AddProfesorColumn;

-- 4. Datos de prueba mínimos (Profesores)
INSERT IGNORE INTO `profesores` (`Nombre`, `Apellido`, `Cedula`, `Correo`, `Especialidad`) VALUES
('Juan', 'Docente', '8-111-222', 'juan.docente@u.edu.pa', 'Programación Backend'),
('Ana', 'Legal', '4-777-999', 'ana.legal@u.edu.pa', 'Derecho Civil');

INSERT IGNORE INTO `usuarios` (`Nombre`, `Correo`, `Password`, `Rol`) VALUES
('Juan Docente', 'juan.docente@u.edu.pa', '123', 'Profesor');
