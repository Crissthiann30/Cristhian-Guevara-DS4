using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using CristianSemestral.Data;

var builder = WebApplication.CreateBuilder(args);

/////////////////////////
// SERVICIOS
/////////////////////////

// Razor Pages
builder.Services.AddRazorPages();

// MySQL + Laragon (Pomelo)
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        ServerVersion.AutoDetect(
            builder.Configuration.GetConnectionString("DefaultConnection")
        )
    )
);

// Autenticaci�n por Cookies (LOGIN)
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
    });

// Autorizaci�n (Roles)
builder.Services.AddAuthorization();

/////////////////////////
// APP
/////////////////////////

var app = builder.Build();

/////////////////////////
// MIDDLEWARE
/////////////////////////

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// CULTURA (para decimales y fechas)
var supportedCultures = new[] { new CultureInfo("en-US"), new CultureInfo("es-PA") };
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture("en-US"),
    SupportedCultures = supportedCultures,
    SupportedUICultures = supportedCultures
});
cd
app.UseAuthentication();
app.UseAuthorization();

/////////////////////////
// ENDPOINTS
/////////////////////////

app.MapRazorPages();

app.Run();