﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$(document).ready(function () {
    // --- Lógica de Navegación Sidebar (AJAX) ---
    // --- Lógica de Navegación Sidebar (AJAX) ---
    // Usamos delegación de eventos para mayor robustez
    $(document).on('click', '.sidebar-nav a', function (e) {
        var $link = $(this);

        // Verificar si es un enlace válido y no tiene exclusiones
        if ($link.attr('href') &&
            !$link.hasClass('no-ajax') &&
            !$link.hasClass('show-in-modal') &&
            $link.attr('href') !== '#') {

            e.preventDefault();

            var url = $link.attr('href');
            var $menuItem = $link.closest('.nav-item'); // O el propio link si tiene la clase

            // Actualizar estado activo visual
            $('.sidebar-nav .nav-item').removeClass('active');
            if ($link.hasClass('nav-item')) {
                $link.addClass('active');
            } else {
                $link.closest('.nav-item').addClass('active');
            }

            // Mostrar el spinner antes de la petición
            $('#main-content-area').html(`
                <div class="d-flex justify-content-center align-items-center h-100" style="min-height: 400px;">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Cargando...</span>
                    </div>
                </div>
            `);

            // Petición AJAX
            $.get(url, function (data) {
                // Inteligencia para extraer solo el contenido relevante
                var $content;

                // Si la respuesta es un documento HTML completo (tiene <html> o <body>)
                // intentamos buscar el contenedor principal
                var tempDom = $('<div/>').html(data);
                if (tempDom.find('#main-content-area').length > 0) {
                    $content = tempDom.find('#main-content-area').html();
                } else {
                    // Si no encuentra el contenedor, usa todo el body o la data
                    $content = data;
                }

                $('#main-content-area').html($content);

                // Actualizar la URL del navegador sin recargar (Historial)
                // window.history.pushState({path: url}, '', url); // Opcional, si queremos que la URL cambie
            }).fail(function () {
                $('#main-content-area').html(`
                    <div class="alert alert-danger m-4" role="alert">
                        <i class="bi bi-exclamation-triangle-fill"></i> Error al cargar el contenido.
                    </div>
                `);
            });
        }
    });

    // --- Lógica para Modales AJAX (.show-in-modal) ---
    $('body').on('click', '.show-in-modal', function (e) {
        e.preventDefault();
        var url = $(this).attr('href');
        var $modal = $('#genericModal');
        var $modalBody = $('#genericModalBody');

        // Limpiar y mostrar spinner
        $modalBody.html(`
            <div class="text-center p-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
            </div>
        `);

        $modal.modal('show');

        // Cargar contenido
        $.get(url, function (data) {
            var $content = $(data).find('#main-content-area').length > 0
                ? $(data).find('#main-content-area').html()
                : data;

            $modalBody.html($content);

            // Re-bindear validaciones de jQuery Unobtrusive
            if ($.validator && $.validator.unobtrusive) {
                $.validator.unobtrusive.parse($modalBody);
            }
        }).fail(function () {
            $modalBody.html(`
                <div class="alert alert-danger m-3">
                    <i class="bi bi-exclamation-triangle"></i> Error al cargar el formulario.
                </div>
            `);
        });
    });

    // --- Manejo de Submit de Formularios dentro del Modal ---
    $(document).on('submit', '.modal-content form', function (e) {
        e.preventDefault();
        e.stopPropagation(); // Evitar que otros handlers interfieran

        var $form = $(this);
        // Validar manualmente si jquery validation está activo y falla
        if ($form.valid && !$form.valid()) {
            return; // Detener si no es válido
        }

        var url = $form.attr('action') || window.location.href;
        var data = $form.serialize();
        var $btn = $form.find('button[type="submit"]');

        // Deshabilitar botón para evitar doble envío
        $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Guardando...');

        $.post(url, data, function (response) {
            var $resp = $(response);
            // Detectar errores explícitamente por clases de validación
            var hasValidationErrors = $resp.find('.validation-summary-errors').length > 0 || $resp.find('.field-validation-error').length > 0;
            // Detectar si la respuesta es la MISMA página de creación (tiene el form específico de matrícula)
            // Esto evita confundirse con un form de búsqueda en el Layout si redirecciona al Index
            var isSameForm = $resp.find('form[action*="Create"]').length > 0 || $resp.find('input[name="Matricula.MateriaId"]').length > 0;

            if (hasValidationErrors || isSameForm) {
                var $content = $resp.find('#main-content-area').length > 0 ? $resp.find('#main-content-area').html() : response;
                $('#genericModalBody').html($content);
                // Reactivar validación unobtrusive para el nuevo contenido
                if ($.validator && $.validator.unobtrusive) {
                    $.validator.unobtrusive.parse('#genericModalBody');
                }
            } else {
                $('#genericModal').modal('hide');

                // Recargar el contenido principal
                var currentUrl = $('.sidebar-nav .nav-item.active a').attr('href');
                if (currentUrl) {
                    $('a[href="' + currentUrl + '"]').click();
                } else {
                    location.reload();
                }
            }
        }).fail(function () {
            alert("Error al procesar la solicitud.");
            $btn.prop('disabled', false).text('Guardar');
        });
    });
});

