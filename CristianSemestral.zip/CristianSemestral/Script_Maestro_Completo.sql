-- --------------------------------------------------------
-- SCRIPT MAESTRO: SISTEMA DE MATRICULAS COMPLETO
-- Incluye: Estudiantes, Profesores, Materias, Carreras, Usuarios
-- --------------------------------------------------------

DROP DATABASE IF EXISTS `estudiantes_db`;
CREATE DATABASE IF NOT EXISTS `estudiantes_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `estudiantes_db`;

-- 1. TABLA CARRERAS
CREATE TABLE `carreras` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `decano` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- 2. TABLA PROFESORES (Nuevo)
CREATE TABLE `profesores` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `Cedula` varchar(20) NOT NULL,
  `Correo` varchar(100) NOT NULL,
  `Especialidad` varchar(100) DEFAULT NULL,
  `FechaRegistro` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Cedula` (`Cedula`),
  UNIQUE KEY `Correo` (`Correo`)
) ENGINE=InnoDB;

-- 3. TABLA MATERIAS (Actualizada con FKs)
CREATE TABLE `materias` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Codigo` varchar(20) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Descripcion` text,
  `Creditos` int NOT NULL,
  `CarreraID` int DEFAULT NULL,
  `ProfesorID` int DEFAULT NULL, -- Nuevo: Asignación Docente
  `FechaCreacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `CarreraID` (`CarreraID`),
  KEY `ProfesorID` (`ProfesorID`),
  CONSTRAINT `materias_fk_carrera` FOREIGN KEY (`CarreraID`) REFERENCES `carreras` (`id`) ON DELETE SET NULL,
  CONSTRAINT `materias_fk_profesor` FOREIGN KEY (`ProfesorID`) REFERENCES `profesores` (`ID`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 4. TABLA ESTUDIANTES
CREATE TABLE `estudiantes` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `Cedula` varchar(20) NOT NULL,
  `Correo` varchar(100) NOT NULL,
  `CarreraID` int NOT NULL,
  `CreditosDisponibles` int DEFAULT 120, -- Bolsa inicial de créditos
  `FechaRegistro` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Cedula` (`Cedula`),
  UNIQUE KEY `Correo` (`Correo`),
  KEY `CarreraID` (`CarreraID`),
  CONSTRAINT `estudiantes_fk_carrera` FOREIGN KEY (`CarreraID`) REFERENCES `carreras` (`id`)
) ENGINE=InnoDB;

-- 5. TABLA INSCRIPCIONES (Actualizada con Nota)
CREATE TABLE `inscripciones` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EstudianteID` int NOT NULL,
  `MateriaID` int NOT NULL,
  `FechaInscripcion` datetime DEFAULT CURRENT_TIMESTAMP,
  `Estado` varchar(20) DEFAULT 'Activa',
  `Nota` decimal(4,2) DEFAULT NULL, -- Nuevo: Calificación (0.00 - 100.00)
  PRIMARY KEY (`ID`),
  KEY `EstudianteID` (`EstudianteID`),
  KEY `MateriaID` (`MateriaID`),
  CONSTRAINT `inscripciones_fk_estudiante` FOREIGN KEY (`EstudianteID`) REFERENCES `estudiantes` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `inscripciones_fk_materia` FOREIGN KEY (`MateriaID`) REFERENCES `materias` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 6. TABLA USUARIOS (Login)
CREATE TABLE `usuarios` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) NOT NULL,
  `Correo` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Rol` varchar(50) DEFAULT 'Admin', -- Admin, Estudiante, Profesor
  `FechaRegistro` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Correo` (`Correo`)
) ENGINE=InnoDB;

-- 7. TABLA EVENTOS (Calendario)
CREATE TABLE `eventos` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Titulo` varchar(100) NOT NULL,
  `Descripcion` text,
  `FechaInicio` datetime NOT NULL,
  `FechaFin` datetime NOT NULL,
  `Tipo` varchar(50) DEFAULT 'Personal',
  `UsuarioID` int DEFAULT NULL, -- Para eventos privados
  `Color` varchar(20) DEFAULT 'primary', -- bootstrap class
  PRIMARY KEY (`ID`),
  KEY `UsuarioID` (`UsuarioID`),
  CONSTRAINT `eventos_fk_usuario` FOREIGN KEY (`UsuarioID`) REFERENCES `usuarios` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- DATOS DE PRUEBA (SEEDING)
INSERT INTO `carreras` (`nombre`, `decano`) VALUES 
('Ingeniería de Sistemas', 'Ing. Carlos Ruiz'),
('Licenciatura en Derecho', 'Dr. Ana Polo');

-- Profesores
INSERT INTO `profesores` (`Nombre`, `Apellido`, `Cedula`, `Correo`, `Especialidad`) VALUES
('Juan', 'Docente', '8-111-222', 'juan.docente@u.edu.pa', 'Programación Backend'),
('Ana', 'Legal', '4-777-999', 'ana.legal@u.edu.pa', 'Derecho Civil');

-- Usuarios (Login)
INSERT INTO `usuarios` (`Nombre`, `Correo`, `Password`, `Rol`) VALUES
('Administrador', 'admin@sistema.com', '123', 'Admin'),
('Juan Docente', 'juan.docente@u.edu.pa', '123', 'Profesor'),
('Ana Legal', 'ana.legal@u.edu.pa', '123', 'Profesor'),
('Cristian Estudiante', 'cristian@u.edu.pa', '123', 'Estudiante'),
('Maria Estudiante', 'maria@u.edu.pa', '123', 'Estudiante');

-- Estudiantes (Perfiles)
INSERT INTO `estudiantes` (`Nombre`, `Apellido`, `Cedula`, `Correo`, `CarreraID`, `CreditosDisponibles`) VALUES
('Cristian', 'Estudiante', '8-123-4567', 'cristian@u.edu.pa', 1, 120), -- Sistemas
('Maria', 'Estudiante', '3-456-7890', 'maria@u.edu.pa', 2, 120); -- Derecho

-- Materias
INSERT INTO `materias` (`Codigo`, `Nombre`, `Creditos`, `CarreraID`, `ProfesorID`) VALUES
('SIS-101', 'Programación I', 4, 1, 1), -- Sistemas, Prof. Juan
('SIS-102', 'Bases de Datos', 3, 1, 1),
('DER-101', 'Intro al Derecho', 3, 2, 2); -- Derecho, Prof. Ana

-- Inscripciones (Datos de prueba)
INSERT INTO `inscripciones` (`EstudianteID`, `MateriaID`, `Nota`) VALUES
(1, 1, 85.5), -- Cristian en progra
(1, 2, NULL); -- Cristian en BD (sin nota aun)
