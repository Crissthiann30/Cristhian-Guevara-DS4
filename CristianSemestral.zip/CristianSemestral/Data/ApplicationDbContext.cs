using Microsoft.EntityFrameworkCore;
using CristianSemestral.Models;

namespace CristianSemestral.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Estudiante> Estudiantes { get; set; } = default!;
        public DbSet<Materia> Materias { get; set; } = default!;
        public DbSet<Matricula> Inscripciones { get; set; } = default!;
        public DbSet<Carrera> Carreras { get; set; } = default!;
        public DbSet<Usuario> Usuarios { get; set; } = default!;
        public DbSet<Profesor> Profesores { get; set; } = default!;
        public DbSet<Evento> Eventos { get; set; } = default!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Mapeo explicito a nombres de tablas en español según imagen
            modelBuilder.Entity<Estudiante>().ToTable("estudiantes");
            modelBuilder.Entity<Materia>().ToTable("materias");
            modelBuilder.Entity<Matricula>().ToTable("inscripciones");
            modelBuilder.Entity<Carrera>().ToTable("carreras");
            modelBuilder.Entity<Usuario>().ToTable("usuarios");
            modelBuilder.Entity<Profesor>().ToTable("profesores");
        }
    }
}
