USE `estudiantes_db`;

-- CORRECCIÓN CRÍTICA:
-- El tipo DECIMAL(4,2) solo permite hasta 99.99
-- Para permitir la nota 100.00, necesitamos DECIMAL(5,2)

ALTER TABLE `inscripciones` MODIFY COLUMN `Nota` decimal(5,2) DEFAULT NULL;

-- Verificación opcional
DESCRIBE `inscripciones`;
