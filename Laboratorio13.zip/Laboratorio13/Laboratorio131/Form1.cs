using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Laboratorio131
{
    public partial class Form1 : Form
    {
        string connectionString =
        @"Server=.\sqlexpress;Database=Northwind;TrustServerCertificate=true;Integrated Security=SSPI;";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnConectar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conexion = new SqlConnection(connectionString);
                conexion.Open();
                MessageBox.Show("✅ Conexión abierta correctamente con la base de datos Northwind.");

                listBoxProductos.Items.Clear();
                SqlCommand cmd = new SqlCommand("SELECT ProductName FROM [dbo].[Products]", conexion);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    listBoxProductos.Items.Add(reader["ProductName"].ToString());
                }

                reader.Close();
                conexion.Close();
                MessageBox.Show("🔒 Conexión cerrada correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Error: " + ex.Message);
            }
        }
    }
}