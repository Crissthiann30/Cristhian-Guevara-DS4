using System;

class Program
{
    static void Main(string[] args)
    {
        string[] frutas = { "manzana", "plátano", "naranja" };

        foreach (string fruta in frutas)
        {
            Console.WriteLine(fruta);
        }
        Console.ReadKey();
    }
}