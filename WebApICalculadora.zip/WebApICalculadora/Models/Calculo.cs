using System;

namespace WebApICalculadora.Models
{
    public class Calculo
    {
        public int Id { get; set; }
        public decimal Numero1 { get; set; }
        public decimal Numero2 { get; set; }
        public string Operacion { get; set; } = null!;
        public decimal Resultado { get; set; }
        public DateTime FechaRegistro { get; set; }
    }
}