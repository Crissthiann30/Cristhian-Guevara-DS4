CREATE DATABASE CalculadoraDB;
GO
USE CalculadoraDB;
GO
CREATE TABLE HistorialCalculos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Operacion NVARCHAR(200),
    Resultado DECIMAL(18,4),
    Fecha DATETIME DEFAULT GETDATE()
);