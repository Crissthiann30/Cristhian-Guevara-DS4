using Microsoft.EntityFrameworkCore;
using WebApICalculadora.Models;

namespace WebApICalculadora.Data
{
    public class CalculadoraDbContext : DbContext
    {
        public CalculadoraDbContext(DbContextOptions<CalculadoraDbContext> options) : base(options)
        {
        }

        public DbSet<Calculo> Calculos { get; set; } = null!;
    }
}