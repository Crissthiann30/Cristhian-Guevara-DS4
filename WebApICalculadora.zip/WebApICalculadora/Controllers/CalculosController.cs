using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApICalculadora.Data;
using WebApICalculadora.Models;

namespace WebApICalculadora.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CalculosController : ControllerBase
    {
        private readonly CalculadoraDbContext _context;

        public CalculosController(CalculadoraDbContext context)
        {
            _context = context;
        }

        // GET: api/calculos
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _context.Calculos.OrderByDescending(c => c.FechaRegistro).ToListAsync());
        }

        // GET: api/calculos/sumas
        [HttpGet("sumas")]
        public async Task<IActionResult> GetSumas()
        {
            return Ok(await _context.Calculos.Where(c => c.Operacion == "Suma").ToListAsync());
        }

        // GET: api/calculos/restas
        [HttpGet("restas")]
        public async Task<IActionResult> GetRestas()
        {
            return Ok(await _context.Calculos.Where(c => c.Operacion == "Resta").ToListAsync());
        }

        // GET: api/calculos/multiplicaciones
        [HttpGet("multiplicaciones")]
        public async Task<IActionResult> GetMultiplicaciones()
        {
            return Ok(await _context.Calculos.Where(c => c.Operacion == "Multiplicacion").ToListAsync());
        }

        // GET: api/calculos/divisiones
        [HttpGet("divisiones")]
        public async Task<IActionResult> GetDivisiones()
        {
            return Ok(await _context.Calculos.Where(c => c.Operacion == "Division").ToListAsync());
        }

        // GET: api/calculos/libre?minResultado=100
        [HttpGet("libre")]
        public async Task<IActionResult> GetLibre([FromQuery] decimal? minResultado)
        {
            var query = _context.Calculos.AsQueryable();

            if (minResultado.HasValue)
                query = query.Where(c => c.Resultado >= minResultado.Value);

            return Ok(await query.OrderByDescending(c => c.FechaRegistro).ToListAsync());
        }

        // POST: api/calculos
        [HttpPost]
        public async Task<IActionResult> CreateCalculo([FromBody] Calculo model)
        {
            model.FechaRegistro = DateTime.Now;

            _context.Calculos.Add(model);
            await _context.SaveChangesAsync();

            return Ok(model);
        }
    }
}