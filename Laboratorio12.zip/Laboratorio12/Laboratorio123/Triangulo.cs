using System;

namespace Laboratorio123
{
    public class Triangulo
    {
        private double lado1, lado2, lado3;

        public Triangulo(double l1, double l2, double l3)
        {
            lado1 = l1;
            lado2 = l2;
            lado3 = l3;
        }

        public double Semiperimetro()
        {
            return (lado1 + lado2 + lado3) / 2;
        }

        public double Area()
        {
            double s = Semiperimetro();
            return Math.Sqrt(s * (s - lado1) * (s - lado2) * (s - lado3));
        }
    }
}