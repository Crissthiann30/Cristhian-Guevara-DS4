using System;
using System.Windows.Forms;

namespace Laboratorio123
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double a = Convert.ToDouble(txtLado1.Text);
            double b = Convert.ToDouble(txtLado2.Text);
            double c = Convert.ToDouble(txtLado3.Text);
            Triangulo t = new Triangulo(a, b, c);
            lblResultado.Text = $"Semiperímetro: {t.Semiperimetro():F2}\nÁrea: {t.Area():F2}";
        }
    }
}