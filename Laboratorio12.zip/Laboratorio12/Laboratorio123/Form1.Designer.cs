namespace Laboratorio123
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtLado1 = new System.Windows.Forms.TextBox();
            this.txtLado2 = new System.Windows.Forms.TextBox();
            this.txtLado3 = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtLado1
            // 
            this.txtLado1.Location = new System.Drawing.Point(30, 30);
            this.txtLado1.PlaceholderText = "Lado 1";
            this.txtLado1.Size = new System.Drawing.Size(200, 23);
            // 
            // txtLado2
            // 
            this.txtLado2.Location = new System.Drawing.Point(30, 70);
            this.txtLado2.PlaceholderText = "Lado 2";
            this.txtLado2.Size = new System.Drawing.Size(200, 23);
            // 
            // txtLado3
            // 
            this.txtLado3.Location = new System.Drawing.Point(30, 110);
            this.txtLado3.PlaceholderText = "Lado 3";
            this.txtLado3.Size = new System.Drawing.Size(200, 23);
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(30, 150);
            this.btnCalcular.Size = new System.Drawing.Size(200, 30);
            this.btnCalcular.Text = "Calcular Área y Semiperímetro";
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(30, 200);
            this.lblResultado.Text = "Resultado:";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(300, 250);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtLado3);
            this.Controls.Add(this.txtLado2);
            this.Controls.Add(this.txtLado1);
            this.Name = "Form1";
            this.Text = "Laboratorio 12-3";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtLado1;
        private System.Windows.Forms.TextBox txtLado2;
        private System.Windows.Forms.TextBox txtLado3;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}