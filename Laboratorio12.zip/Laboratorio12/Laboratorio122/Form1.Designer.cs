namespace Laboratorio122
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtNota1 = new System.Windows.Forms.TextBox();
            this.txtNota2 = new System.Windows.Forms.TextBox();
            this.txtNota3 = new System.Windows.Forms.TextBox();
            this.btnPromedio = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtNota1
            // 
            this.txtNota1.Location = new System.Drawing.Point(30, 30);
            this.txtNota1.PlaceholderText = "Nota 1";
            this.txtNota1.Size = new System.Drawing.Size(200, 23);
            // 
            // txtNota2
            // 
            this.txtNota2.Location = new System.Drawing.Point(30, 70);
            this.txtNota2.PlaceholderText = "Nota 2";
            this.txtNota2.Size = new System.Drawing.Size(200, 23);
            // 
            // txtNota3
            // 
            this.txtNota3.Location = new System.Drawing.Point(30, 110);
            this.txtNota3.PlaceholderText = "Nota 3";
            this.txtNota3.Size = new System.Drawing.Size(200, 23);
            // 
            // btnPromedio
            // 
            this.btnPromedio.Location = new System.Drawing.Point(30, 150);
            this.btnPromedio.Size = new System.Drawing.Size(200, 30);
            this.btnPromedio.Text = "Calcular Promedio";
            this.btnPromedio.Click += new System.EventHandler(this.btnPromedio_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(30, 200);
            this.lblResultado.Text = "Resultado:";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(270, 250);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnPromedio);
            this.Controls.Add(this.txtNota3);
            this.Controls.Add(this.txtNota2);
            this.Controls.Add(this.txtNota1);
            this.Name = "Form1";
            this.Text = "Laboratorio 12-2";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtNota1;
        private System.Windows.Forms.TextBox txtNota2;
        private System.Windows.Forms.TextBox txtNota3;
        private System.Windows.Forms.Button btnPromedio;
        private System.Windows.Forms.Label lblResultado;
    }
}