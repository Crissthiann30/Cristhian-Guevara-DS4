using System;
using System.Windows.Forms;

namespace Laboratorio122
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnPromedio_Click(object sender, EventArgs e)
        {
            double n1 = Convert.ToDouble(txtNota1.Text);
            double n2 = Convert.ToDouble(txtNota2.Text);
            double n3 = Convert.ToDouble(txtNota3.Text);
            PromedioNotas promedio = new PromedioNotas(n1, n2, n3);
            lblResultado.Text = $"Promedio: {promedio.CalcularPromedio():F2}";
        }
    }
}