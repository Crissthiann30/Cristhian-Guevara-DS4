using System;
using System.Windows.Forms;

namespace Laboratorio121
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double velocidad = Convert.ToDouble(txtVelocidad.Text);
            double tiempo = Convert.ToDouble(txtTiempo.Text);
            CalculoDistancia calc = new CalculoDistancia(velocidad, tiempo);
            lblResultado.Text = $"Distancia recorrida: {calc.Calcular()} km";
        }
    }
}