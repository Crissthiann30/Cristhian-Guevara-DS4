namespace Laboratorio121
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtVelocidad = new System.Windows.Forms.TextBox();
            this.txtTiempo = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtVelocidad
            // 
            this.txtVelocidad.Location = new System.Drawing.Point(30, 30);
            this.txtVelocidad.Name = "txtVelocidad";
            this.txtVelocidad.PlaceholderText = "Velocidad (km/h)";
            this.txtVelocidad.Size = new System.Drawing.Size(200, 23);
            this.txtVelocidad.TabIndex = 0;
            // 
            // txtTiempo
            // 
            this.txtTiempo.Location = new System.Drawing.Point(30, 70);
            this.txtTiempo.Name = "txtTiempo";
            this.txtTiempo.PlaceholderText = "Tiempo (h)";
            this.txtTiempo.Size = new System.Drawing.Size(200, 23);
            this.txtTiempo.TabIndex = 1;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(30, 110);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(200, 30);
            this.btnCalcular.TabIndex = 2;
            this.btnCalcular.Text = "Calcular Distancia";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(30, 160);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(66, 15);
            this.lblResultado.TabIndex = 3;
            this.lblResultado.Text = "Resultado:";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(270, 220);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtTiempo);
            this.Controls.Add(this.txtVelocidad);
            this.Name = "Form1";
            this.Text = "Laboratorio 12-1";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtVelocidad;
        private System.Windows.Forms.TextBox txtTiempo;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResultado;
    }
}