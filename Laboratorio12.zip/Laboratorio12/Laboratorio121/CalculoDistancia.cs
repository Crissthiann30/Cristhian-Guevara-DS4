namespace Laboratorio121
{
    public class CalculoDistancia
    {
        private double velocidad;
        private double tiempo;

        public CalculoDistancia(double v, double t)
        {
            velocidad = v;
            tiempo = t;
        }

        public double Calcular()
        {
            return velocidad * tiempo;
        }
    }
}