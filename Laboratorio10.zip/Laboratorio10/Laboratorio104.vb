Class Perro
    Public Nombre As String
    Public Raza As String
    Public Altura As Single

    ' Constructor vacío
    Public Sub New()
    End Sub

    ' Constructor con parámetros
    Public Sub New(n As String, r As String, a As Single)
        Nombre = n
        Raza = r
        Altura = a
    End Sub

    Public Sub Comer()
        Console.WriteLine(Nombre & " está comiendo.")
    End Sub

    Public Sub Dormir()
        Console.WriteLine(Nombre & " está durmiendo.")
    End Sub

    Public Sub Ladrar()
        Console.WriteLine(Nombre & " dice: ¡Guau!")
    End Sub

    Public Function CalcularCosto() As Single
        Return Altura * 10 ' Ejemplo de cálculo de costo
    End Function
End Class

Module Laboratorio104

    Sub Main()
        Dim miPerro As New Perro("Toby", "Labrador", 0.6)

        miPerro.Comer()
        miPerro.Dormir()
        miPerro.Ladrar()
        Console.WriteLine("Costo estimado: " & miPerro.CalcularCosto())

        Console.ReadKey()
    End Sub

End Module