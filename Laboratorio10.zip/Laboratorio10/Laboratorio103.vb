Module Laboratorio103

    Sub Main()
        Dim masa As Single
        Const gravedad As Single = 9.81
        Dim peso As Single

        Console.Write("Ingrese la masa en kg: ")
        masa = Single.Parse(Console.ReadLine())

        peso = masa * gravedad
        Console.WriteLine("El peso del objeto es: {0} N", peso)

        Console.ReadKey()
    End Sub

End Module