using System;

namespace Laboratorio2
{
    // Clase para demostrar variables de instancia (referencia)
    class Persona
    {
        // variable de instancia
        public string Nombre;
        public int Edad;

        public Persona(string nombre, int edad)
        {
            Nombre = nombre;
            Edad = edad;
        }

        public void Mostrar()
        {
            Console.WriteLine($"Persona -> Nombre: {Nombre}, Edad: {Edad}");
        }
    }

    // Clase para demostrar variable de clase (estática)
    class Contador
    {
        // variable de clase / estática
        public static int TotalInstancias = 0;

        public Contador()
        {
            TotalInstancias++;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===== Laboratorio 2 - Sintaxis básica en C# =====");
            Console.WriteLine();

            // --- Variables locales ---
            int numeroEntero = 42;
            long numeroLargo = 3000000000L;
            float numeroFloat = 3.14f;
            double numeroDouble = 3.14159265359;
            decimal numeroDecimal = 12.34567m;
            char caracter = 'A';
            string texto = "Hola, Laboratorio2";
            bool esVerdadero = true;

            Console.WriteLine("-- Tipos básicos (variables locales) --");
            Console.WriteLine($"int: {numeroEntero}");
            Console.WriteLine($"long: {numeroLargo}");
            Console.WriteLine($"float: {numeroFloat}");
            Console.WriteLine($"double: {numeroDouble}");
            Console.WriteLine($"decimal: {numeroDecimal}");
            Console.WriteLine($"char: {caracter}");
            Console.WriteLine($"string: {texto}");
            Console.WriteLine($"bool: {esVerdadero}");
            Console.WriteLine();

            // --- Comportamiento: tipos de valor (copian el valor) ---
            Console.WriteLine("-- Tipos de valor: copia de valor --");
            int valor1 = 28;
            int valor2 = valor1; // copia
            Console.WriteLine($"Antes: valor1 = {valor1}, valor2 = {valor2}");
            valor2 = 30;
            Console.WriteLine($"Después cambio valor2 a 30 -> valor1 = {valor1}, valor2 = {valor2}");
            Console.WriteLine("Explicación: los tipos de valor copian el dato, por eso valor1 no cambia.");
            Console.WriteLine();

            // --- Comportamiento: tipos de referencia (apuntan al mismo objeto) ---
            Console.WriteLine("-- Tipos de referencia: apuntan al mismo objeto --");
            Persona p1 = new Persona("Ana", 25);
            Persona p2 = p1; // referencia al mismo objeto
            Console.WriteLine("Antes de cambiar p2:");
            p1.Mostrar();
            p2.Mostrar();

            p2.Nombre = "Bea";
            p2.Edad = 26;
            Console.WriteLine("Después de cambiar p2:");
            p1.Mostrar();
            p2.Mostrar();
            Console.WriteLine("Explicación: ambas variables apuntan al mismo objeto en memoria.");
            Console.WriteLine();

            // --- Variables estáticas / de clase ---
            Console.WriteLine("-- Variables estáticas (de clase) --");
            Console.WriteLine($"TotalInstancias (antes) = {Contador.TotalInstancias}");
            new Contador();
            new Contador();
            Console.WriteLine($"TotalInstancias (después de crear 2 objetos) = {Contador.TotalInstancias}");
            Console.WriteLine();

            // --- Métodos y variables locales dentro de métodos ---
            Console.WriteLine("-- Ejemplo de variable local dentro de un método --");
            SumarEjemplo();
            Console.WriteLine();

            // --- Lectura por consola (ejemplo simple) ---
            Console.WriteLine("-- Entrada por consola (ejemplo) --");
            Console.Write("Ingrese un número entero: ");
            string linea = Console.ReadLine();
            int n;
            if (int.TryParse(linea, out n))
            {
                Console.WriteLine($"Usted ingresó {n}, el doble es {n * 2}");
            }
            else
            {
                Console.WriteLine("Entrada inválida. No es un entero.");
            }

            Console.WriteLine();
            Console.WriteLine("===== Fin de la demostración =====");
            Console.WriteLine("Presione ENTER para salir...");
            Console.ReadLine();
        }

        // Método que demuestra variable local
        static void SumarEjemplo()
        {
            int a = 10; // variable local
            int b = 20; // variable local
            int suma = a + b; // variable local
            Console.WriteLine($"Suma local: {a} + {b} = {suma}");
        }
    }
}