using System;

class Program
{
    static void checkAge(int age)
    {
        if (age < 18)
        {
            throw new ArithmeticException("Acceso negado - No cumple con el criterio de edad");
        }
        else
        {
            Console.WriteLine("Acceso Concedido - Edad suficiente");
        }
    }

    static void Main(string[] args)
    {
        Console.Write("Ingrese su edad: ");
        int edad = int.Parse(Console.ReadLine());

        try
        {
            checkAge(edad);
        }
        catch (ArithmeticException e)
        {
            Console.WriteLine("Excepción capturada: " + e.Message);
        }
        finally
        {
            Console.WriteLine("Fin del programa");
        }

        Console.ReadKey();
    }
}