<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="Laboratorio16.WebForm1" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Segundo Formulario</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
</head>
<body style="font-family: 'Montserrat', sans-serif; text-align:center; margin-top:80px;">
    <form id="form1" runat="server">
        <h2>Segundo Formulario</h2>
        <asp:TextBox ID="txtNombre" runat="server" Placeholder="Nombre" 
            Style="padding:8px; border-radius:5px; border:1px solid #ccc;"></asp:TextBox><br /><br />
        <asp:TextBox ID="txtApellido" runat="server" Placeholder="Apellido" 
            Style="padding:8px; border-radius:5px; border:1px solid #ccc;"></asp:TextBox><br /><br />
        <asp:Button ID="btnMostrar" runat="server" Text="Mostrar Mensaje" 
            OnClick="btnMostrar_Click" 
            Style="padding:10px 20px; border:none; background-color:#444; color:white; border-radius:5px;" />
        <br /><br />
        <asp:Label ID="lblMensaje" runat="server" Font-Bold="true"></asp:Label><br /><br />
        <a href="Default.aspx" style="text-decoration:none; color:#007bff;">Volver a la página principal</a>
    </form>
</body>
</html>