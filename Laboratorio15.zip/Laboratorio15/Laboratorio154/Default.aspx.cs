using System;
using System.Web.UI;

namespace Laboratorio154
{
    public partial class _Default : Page
    {
        protected void btnSumar_Click(object sender, EventArgs e)
        {
            try
            {
                double num1 = double.Parse(txtNum1.Text);
                double num2 = double.Parse(txtNum2.Text);
                double suma = num1 + num2;

                lblResultado.Text = $"El resultado de la suma es: {suma}";
            }
            catch
            {
                lblResultado.Text = "Por favor ingrese números válidos.";
            }
        }
    }
}