<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Laboratorio154._Default" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Laboratorio 15-4</title>
</head>
<body>
    <form id="form1" runat="server">
        <div style="text-align:center; margin-top:50px;">
            <h2>Sumar dos números</h2>
            <asp:TextBox ID="txtNum1" runat="server" Width="150" Placeholder="Número 1"></asp:TextBox><br /><br />
            <asp:TextBox ID="txtNum2" runat="server" Width="150" Placeholder="Número 2"></asp:TextBox><br /><br />
            <asp:Button ID="btnSumar" runat="server" Text="Sumar" OnClick="btnSumar_Click" /><br /><br />
            <asp:Label ID="lblResultado" runat="server" Font-Bold="True"></asp:Label>
        </div>
    </form>
</body>
</html>