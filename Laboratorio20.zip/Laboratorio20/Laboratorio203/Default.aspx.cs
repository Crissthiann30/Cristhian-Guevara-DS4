using System.Data.SqlClient;

namespace Laboratorio203
{
    public class ConexionDB
    {
        public SqlConnection Conectar()
        {
            SqlConnection cn = new SqlConnection(
                "SERVER=localhost;DATABASE=Laboratorio14;Integrated Security=true;"
            );
            return cn;
        }
    }
}