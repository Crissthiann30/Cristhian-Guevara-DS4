using System.Web.Http;
using Laboratorio191.Models.WS;

namespace Laboratorio191.Controllers
{
    public class AccessController : ApiController
    {
        [HttpGet]
        public Reply HelloWorld()
        {
            return new Reply
            {
                result = 200,
                data = null,
                message = "Hola desde mi Web API"
            };
        }
    }
}