<!DOCTYPE html>
<html>
<head>
    <title>Laboratorio 19-2</title>
</head>
<body>

<h2>Obtener TODOS los valores</h2>

<button onclick="loadData()">Traer datos</button>

<pre id="resultado"></pre>

<script>
function loadData(){
    var url = "https://localhost:44360/api/values";

    fetch(url)
    .then(r => r.json())
    .then(d => {
        document.getElementById("resultado").innerText = JSON.stringify(d, null, 4);
    })
    .catch(() => alert("Error llamando API"));
}
</script>

</body>
</html>