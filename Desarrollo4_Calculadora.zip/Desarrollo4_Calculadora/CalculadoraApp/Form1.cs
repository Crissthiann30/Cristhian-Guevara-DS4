using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CalculadoraApp
{
    public partial class Form1 : Form
    {
        double valor1 = 0;
        double valor2 = 0;
        string operacion = "";
        bool operacionEnCurso = false;
        string connectionString = "Server=localhost;Database=CalculadoraDB;Trusted_Connection=True;";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (txtDisplay.Text == "0" || operacionEnCurso)
            {
                txtDisplay.Text = "";
                operacionEnCurso = false;
            }
            txtDisplay.Text += b.Text;
        }

        private void btnOperacion_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            double.TryParse(txtDisplay.Text, out valor1);
            operacion = b.Text;
            operacionEnCurso = true;
        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            double.TryParse(txtDisplay.Text, out valor2);
            double resultado = 0;
            switch (operacion)
            {
                case "+": resultado = valor1 + valor2; break;
                case "−": resultado = valor1 - valor2; break;
                case "×": resultado = valor1 * valor2; break;
                case "÷":
                    if (valor2 == 0)
                    {
                        MessageBox.Show("Error: División entre cero");
                        return;
                    }
                    resultado = valor1 / valor2;
                    break;
            }

            txtDisplay.Text = resultado.ToString();
            GuardarCalculo($"{valor1} {operacion} {valor2}", resultado);
            operacionEnCurso = true;
        }

        private void btnRaiz_Click(object sender, EventArgs e)
        {
            double num = double.Parse(txtDisplay.Text);
            if (num < 0)
            {
                MessageBox.Show("No se puede calcular raíz negativa");
                return;
            }
            double resultado = Math.Sqrt(num);
            txtDisplay.Text = resultado.ToString();
            GuardarCalculo($"√{num}", resultado);
        }

        private void btnCuadrado_Click(object sender, EventArgs e)
        {
            double num = double.Parse(txtDisplay.Text);
            double resultado = num * num;
            txtDisplay.Text = resultado.ToString();
            GuardarCalculo($"{num}²", resultado);
        }

        private void btnSigno_Click(object sender, EventArgs e)
        {
            double num = double.Parse(txtDisplay.Text);
            txtDisplay.Text = (num * -1).ToString();
        }

        private void btnCE_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "0";
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "0";
            valor1 = valor2 = 0;
            operacion = "";
        }

        private void btnPunto_Click(object sender, EventArgs e)
        {
            if (!txtDisplay.Text.Contains("."))
                txtDisplay.Text += ".";
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM HistorialCalculos ORDER BY Fecha DESC";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvHistorial.DataSource = dt;
                dgvHistorial.Visible = true;
            }
        }

        private void GuardarCalculo(string operacionTxt, double resultado)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO HistorialCalculos (Operacion, Resultado) VALUES (@Operacion, @Resultado)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Operacion", operacionTxt);
                cmd.Parameters.AddWithValue("@Resultado", resultado);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
    }
}