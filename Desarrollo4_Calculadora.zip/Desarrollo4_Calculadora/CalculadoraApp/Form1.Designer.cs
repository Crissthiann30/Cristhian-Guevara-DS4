namespace CalculadoraApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.dgvHistorial = new System.Windows.Forms.DataGridView();
            this.btnMostrar = new System.Windows.Forms.Button();

            string[] botones = { "CE", "C", "√", "x²", "7", "8", "9", "÷", "4", "5", "6", "×", "1", "2", "3", "−", "0", ".", "±", "+", "=" };
            System.Drawing.Point loc = new System.Drawing.Point(20, 80);
            int ancho = 60, alto = 45, col = 0, fila = 0;

            this.SuspendLayout();

            this.txtDisplay.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.txtDisplay.Location = new System.Drawing.Point(20, 20);
            this.txtDisplay.Size = new System.Drawing.Size(280, 45);
            this.txtDisplay.ReadOnly = true;
            this.txtDisplay.Text = "0";
            this.txtDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Controls.Add(this.txtDisplay);

            for (int i = 0; i < botones.Length; i++)
            {
                System.Windows.Forms.Button btn = new System.Windows.Forms.Button();
                btn.Text = botones[i];
                btn.Size = new System.Drawing.Size(ancho, alto);
                btn.Location = new System.Drawing.Point(20 + (col * (ancho + 5)), 80 + (fila * (alto + 5)));
                btn.Font = new System.Drawing.Font("Segoe UI", 12F);
                btn.BackColor = System.Drawing.Color.LightGray;

                if ("0123456789".Contains(btn.Text))
                    btn.Click += new System.EventHandler(this.btnNumero_Click);
                else if (btn.Text == "." || btn.Text == "±")
                    btn.Click += new System.EventHandler(btn.Text == "." ? this.btnPunto_Click : this.btnSigno_Click);
                else if (btn.Text == "=")
                    btn.Click += new System.EventHandler(this.btnIgual_Click);
                else if (btn.Text == "√")
                    btn.Click += new System.EventHandler(this.btnRaiz_Click);
                else if (btn.Text == "x²")
                    btn.Click += new System.EventHandler(this.btnCuadrado_Click);
                else if (btn.Text == "CE")
                    btn.Click += new System.EventHandler(this.btnCE_Click);
                else if (btn.Text == "C")
                    btn.Click += new System.EventHandler(this.btnC_Click);
                else if ("+−×÷".Contains(btn.Text))
                    btn.Click += new System.EventHandler(this.btnOperacion_Click);

                this.Controls.Add(btn);
                col++;
                if (col == 4) { col = 0; fila++; }
            }

            this.btnMostrar.Text = "Mostrar cálculos";
            this.btnMostrar.Size = new System.Drawing.Size(260, 35);
            this.btnMostrar.Location = new System.Drawing.Point(20, 330);
            this.btnMostrar.Click += new System.EventHandler(this.btnMostrar_Click);
            this.Controls.Add(this.btnMostrar);

            this.dgvHistorial.Location = new System.Drawing.Point(20, 380);
            this.dgvHistorial.Size = new System.Drawing.Size(280, 150);
            this.dgvHistorial.Visible = false;
            this.Controls.Add(this.dgvHistorial);

            this.ClientSize = new System.Drawing.Size(320, 550);
            this.Text = "Calculadora - Desarrollo 4";
            this.BackColor = System.Drawing.Color.FromArgb(240, 240, 240);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.DataGridView dgvHistorial;
        private System.Windows.Forms.Button btnMostrar;
    }
}