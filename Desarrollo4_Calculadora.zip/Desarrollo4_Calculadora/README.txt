Proyecto: Desarrollo4_Calculadora
Lenguaje: C# (.NET 6)
IDE: Visual Studio 2022
Base de datos: SQL Server (local)

Pasos:
1. Ejecutar 'CalculadoraDB.sql' en SQL Server Management Studio.
2. Abrir la carpeta CalculadoraApp en Visual Studio.
3. Ejecutar el proyecto.
4. Realizar operaciones básicas o usar raíz/cuadrado.
5. Pulsar "Mostrar cálculos" para ver el historial guardado.