using System;

namespace Laboratorio83
{
    class Program
    {
        // Sobrecarga 1: enteros
        public int Suma(int a, int b)
        {
            return a + b;
        }

        // Sobrecarga 2: decimales
        public double Suma(double a, double b)
        {
            return a + b;
        }

        // Sobrecarga 3: tres enteros
        public int Suma(int a, int b, int c)
        {
            return a + b + c;
        }

        static void Main(string[] args)
        {
            Program p = new Program();

            Console.WriteLine($"Suma int: {p.Suma(2, 3)}");
            Console.WriteLine($"Suma double: {p.Suma(2.5, 3.8)}");
            Console.WriteLine($"Suma tres enteros: {p.Suma(1, 2, 3)}");

            Console.ReadKey();
        }
    }
}