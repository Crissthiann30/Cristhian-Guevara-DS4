using System;

namespace Laboratorio82
{
    class Cuenta
    {
        public virtual double CalcularInteres(double saldo)
        {
            return saldo * 0.01; // 1%
        }
    }

    class CuentaAhorro : Cuenta
    {
        public override double CalcularInteres(double saldo)
        {
            return saldo * 0.03; // 3%
        }
    }

    class CuentaPlazoFijo : Cuenta
    {
        public override double CalcularInteres(double saldo)
        {
            return saldo * 0.05; // 5%
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Cuenta[] cuentas = new Cuenta[3];
            cuentas[0] = new Cuenta();
            cuentas[1] = new CuentaAhorro();
            cuentas[2] = new CuentaPlazoFijo();

            double saldo = 1000;

            foreach (var c in cuentas)
            {
                Console.WriteLine($"{c.GetType().Name} → Interés: {c.CalcularInteres(saldo)}");
            }

            Console.ReadKey();
        }
    }
}