using System;

namespace Laboratorio88
{
    abstract class Figura
    {
        public abstract double CalcularArea();
    }

    class Circulo : Figura
    {
        public double Radio { get; set; }

        public Circulo(double radio)
        {
            Radio = radio;
        }

        public override double CalcularArea()
        {
            return Math.PI * Radio * Radio;
        }
    }

    class Rectangulo : Figura
    {
        public double Base { get; set; }
        public double Altura { get; set; }

        public Rectangulo(double b, double h)
        {
            Base = b;
            Altura = h;
        }

        public override double CalcularArea()
        {
            return Base * Altura;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Figura f1 = new Circulo(5);
            Figura f2 = new Rectangulo(4, 6);

            Console.WriteLine($"Área círculo: {f1.CalcularArea()}");
            Console.WriteLine($"Área rectángulo: {f2.CalcularArea()}");

            Console.ReadKey();
        }
    }
}