using System;

namespace Laboratorio81
{
    // Clase base (Padre)
    class Persona
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
        public string NIF { get; set; }

        public Persona(string nombre, int edad, string nif)
        {
            Nombre = nombre;
            Edad = edad;
            NIF = nif;
        }

        public void MostrarDatos()
        {
            Console.WriteLine($"Nombre: {Nombre}, Edad: {Edad}, NIF: {NIF}");
        }
    }

    // Clase hija
    class Trabajador : Persona
    {
        public int Sueldo { get; set; }

        public Trabajador(string nombre, int edad, string nif, int sueldo)
            : base(nombre, edad, nif)
        {
            Sueldo = sueldo;
        }

        public void MostrarSueldo()
        {
            Console.WriteLine($"Sueldo: {Sueldo} USD");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Trabajador t1 = new Trabajador("Carlos Pérez", 30, "8-123-456", 1200);
            t1.MostrarDatos();
            t1.MostrarSueldo();

            Console.ReadKey();
        }
    }
}