using System;

namespace Laboratorio87
{
    sealed class Persona
    {
        public void Mostrar()
        {
            Console.WriteLine("Soy una clase final, no puedo heredarse.");
        }
    }

    // ❌ Esto generaría error: class Estudiante : Persona { }

    class Program
    {
        static void Main(string[] args)
        {
            Persona p = new Persona();
            p.Mostrar();

            Console.ReadKey();
        }
    }
}