using System;

namespace Laboratorio86
{
    class Base
    {
        public virtual void Saludar()
        {
            Console.WriteLine("Hola desde Base");
        }

        public virtual void MetodoFinal()
        {
            Console.WriteLine("Este método no se debe sobrescribir.");
        }
    }

    class Derivada : Base
    {
        public override void Saludar()
        {
            Console.WriteLine("Hola desde Derivada");
        }

        public sealed override void MetodoFinal()
        {
            Console.WriteLine("Método sellado, no puede ser sobrescrito.");
        }
    }

    class Otra : Derivada
    {
        // ❌ ERROR si intentas sobreescribir MetodoFinal aquí
    }

    class Program
    {
        static void Main(string[] args)
        {
            Derivada d = new Derivada();
            d.Saludar();
            d.MetodoFinal();

            Console.ReadKey();
        }
    }
}