using System;

namespace Laboratorio89
{
    interface IVehiculo
    {
        void Acelerar();
        void Frenar();
    }

    class Coche : IVehiculo
    {
        public void Acelerar()
        {
            Console.WriteLine("El coche acelera.");
        }

        public void Frenar()
        {
            Console.WriteLine("El coche frena.");
        }
    }

    class Bicicleta : IVehiculo
    {
        public void Acelerar()
        {
            Console.WriteLine("La bicicleta acelera.");
        }

        public void Frenar()
        {
            Console.WriteLine("La bicicleta frena.");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IVehiculo v1 = new Coche();
            IVehiculo v2 = new Bicicleta();

            v1.Acelerar();
            v1.Frenar();

            v2.Acelerar();
            v2.Frenar();

            Console.ReadKey();
        }
    }
}