using System;

namespace Laboratorio85
{
    // Parte 1 de la clase
    partial class Persona
    {
        public string Nombre { get; set; }
    }

    // Parte 2 de la clase
    partial class Persona
    {
        public int Edad { get; set; }

        public void MostrarInfo()
        {
            Console.WriteLine($"Nombre: {Nombre}, Edad: {Edad}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Persona p = new Persona { Nombre = "Luis", Edad = 25 };
            p.MostrarInfo();

            Console.ReadKey();
        }
    }
}