using System;

namespace Laboratorio84
{
    class Estudiante
    {
        private string nombre;
        private int edad;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public int Edad
        {
            get { return edad; }
            set
            {
                if (value > 0) edad = value;
                else Console.WriteLine("La edad debe ser positiva.");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Estudiante e = new Estudiante();
            e.Nombre = "Ana López";
            e.Edad = 20;

            Console.WriteLine($"Nombre: {e.Nombre}, Edad: {e.Edad}");

            Console.ReadKey();
        }
    }
}