using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Laboratorio141
{
    public partial class frmProductos : Form
    {
        string connectionString = @"Server=.\sqlexpress;Database=productos;Trusted_Connection=True;";
        bool nuevo;

        public frmProductos()
        {
            InitializeComponent();
        }

        private void tsbNuevo_Click(object sender, EventArgs e)
        {
            nuevo = true;
            txtId.Clear();
            txtNombre.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
            txtNombre.Focus();
        }

        private void tsbGuardar_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection(connectionString);
            conexion.Open();

            if (nuevo)
            {
                string insertar = "INSERT INTO Laptops (Nombre, Precio, Stock) VALUES (@Nombre, @Precio, @Stock)";
                SqlCommand cmd = new SqlCommand(insertar, conexion);
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@Precio", Convert.ToDecimal(txtPrecio.Text));
                cmd.Parameters.AddWithValue("@Stock", Convert.ToInt32(txtStock.Text));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Registro guardado correctamente.");
            }
            else
            {
                string actualizar = "UPDATE Laptops SET Nombre=@Nombre, Precio=@Precio, Stock=@Stock WHERE Id=@Id";
                SqlCommand cmd = new SqlCommand(actualizar, conexion);
                cmd.Parameters.AddWithValue("@Id", Convert.ToInt32(txtId.Text));
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@Precio", Convert.ToDecimal(txtPrecio.Text));
                cmd.Parameters.AddWithValue("@Stock", Convert.ToInt32(txtStock.Text));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Registro actualizado correctamente.");
            }
            conexion.Close();
        }

        private void tsbCancelar_Click(object sender, EventArgs e)
        {
            txtId.Clear();
            txtNombre.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
        }

        private void tsbEliminar_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection(connectionString);
            conexion.Open();
            string eliminar = "DELETE FROM Laptops WHERE Id=@Id";
            SqlCommand cmd = new SqlCommand(eliminar, conexion);
            cmd.Parameters.AddWithValue("@Id", Convert.ToInt32(txtId.Text));
            cmd.ExecuteNonQuery();
            conexion.Close();
            MessageBox.Show("Registro eliminado correctamente.");
        }

        private void tsbBuscar_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection(connectionString);
            conexion.Open();
            string buscar = "SELECT * FROM Laptops WHERE Id=@Id";
            SqlCommand cmd = new SqlCommand(buscar, conexion);
            cmd.Parameters.AddWithValue("@Id", Convert.ToInt32(tstId.Text));
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                txtId.Text = reader["Id"].ToString();
                txtNombre.Text = reader["Nombre"].ToString();
                txtPrecio.Text = reader["Precio"].ToString();
                txtStock.Text = reader["Stock"].ToString();
                nuevo = false;
            }
            else
            {
                MessageBox.Show("No se encontró el registro.");
            }
            conexion.Close();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}