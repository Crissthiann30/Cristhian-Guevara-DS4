CREATE DATABASE productos;
GO
USE productos;
GO
CREATE TABLE Laptops (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100),
    Precio DECIMAL(10,2),
    Stock INT
);
GO
INSERT INTO Laptops (Nombre, Precio, Stock) VALUES 
('HP Pavilion 15', 850.00, 10),
('ASUS TUF Gaming', 1200.00, 8),
('Lenovo IdeaPad 3', 700.00, 15);
GO