using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Laboratorio17
{
    public partial class _Default : Page
    {
        SqlConnection con = new SqlConnection("Data Source=SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                CargarDatos();
        }

        void CargarDatos()
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT ProductID, ProductName, UnitPrice FROM Products", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            CargarDatos();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            CargarDatos();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GridView1.Rows[e.RowIndex];
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
            string nombre = ((TextBox)row.Cells[1].Controls[0]).Text;
            string precio = ((TextBox)row.Cells[2].Controls[0]).Text;

            SqlCommand cmd = new SqlCommand("UPDATE Products SET ProductName=@n, UnitPrice=@p WHERE ProductID=@id", con);
            cmd.Parameters.AddWithValue("@n", nombre);
            cmd.Parameters.AddWithValue("@p", precio);
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            GridView1.EditIndex = -1;
            CargarDatos();
        }
    }
}