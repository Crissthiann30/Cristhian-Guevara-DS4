using System;

namespace Laboratorio94
{
    class Aleatorios
    {
        private Random rnd;

        public Aleatorios()
        {
            rnd = new Random();
        }

        // Genera un número aleatorio entre min y max (inclusive)
        public int NumeroEntre(int min, int max)
        {
            return rnd.Next(min, max + 1);
        }

        // Genera un arreglo de n números aleatorios entre min y max
        public int[] ArregloEntre(int n, int min, int max)
        {
            int[] arreglo = new int[n];
            for (int i = 0; i < n; i++)
            {
                arreglo[i] = NumeroEntre(min, max);
            }
            return arreglo;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Laboratorio94: Clase Aleatorios ===");
            Aleatorios a = new Aleatorios();

            int numero = a.NumeroEntre(1, 10);
            Console.WriteLine($"Número aleatorio entre 1 y 10: {numero}");

            int[] arreglo = a.ArregloEntre(5, 10, 50);
            Console.WriteLine("Arreglo de 5 números aleatorios entre 10 y 50:");
            foreach (int x in arreglo)
                Console.Write(x + " ");

            Console.WriteLine("\nPresione ENTER para salir...");
            Console.ReadLine();
        }
    }
}