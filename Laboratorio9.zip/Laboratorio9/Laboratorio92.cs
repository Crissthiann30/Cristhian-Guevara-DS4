using System;

namespace Laboratorio92
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Laboratorio92: Números pares o divisibles entre 3 ===");
            for (int i = 1; i <= 100; i++)
            {
                if (i % 2 == 0 || i % 3 == 0)
                {
                    Console.WriteLine(i);
                }
            }

            Console.WriteLine("Presione ENTER para salir...");
            Console.ReadLine();
        }
    }
}