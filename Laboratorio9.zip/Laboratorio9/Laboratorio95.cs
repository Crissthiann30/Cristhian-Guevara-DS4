using System;
using System.Collections.Generic;

namespace Laboratorio95
{
    class Aleatorios
    {
        private Random rnd;

        public Aleatorios()
        {
            rnd = new Random();
        }

        public int NumeroEntre(int min, int max)
        {
            return rnd.Next(min, max + 1);
        }

        public int[] ArregloEntreNoRepetidos(int n, int min, int max)
        {
            if (max - min + 1 < n)
                throw new ArgumentException("Rango demasiado pequeño para generar números no repetidos.");

            HashSet<int> set = new HashSet<int>();
            while (set.Count < n)
            {
                set.Add(NumeroEntre(min, max));
            }
            int[] arreglo = new int[n];
            set.CopyTo(arreglo);
            return arreglo;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Laboratorio95: Arreglo de números no repetidos ===");
            Aleatorios a = new Aleatorios();

            int[] arreglo = a.ArregloEntreNoRepetidos(5, 1, 10);
            Console.WriteLine("Arreglo de números no repetidos entre 1 y 10:");
            foreach (int x in arreglo)
                Console.Write(x + " ");

            Console.WriteLine("\nPresione ENTER para salir...");
            Console.ReadLine();
        }
    }
}