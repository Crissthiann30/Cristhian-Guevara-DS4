using System;

namespace Laboratorio91
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Laboratorio91: Precio y forma de pago ===");

            double precio = 0;
            while (true)
            {
                Console.Write("Ingrese el precio del producto (valor positivo): ");
                if (double.TryParse(Console.ReadLine(), out precio) && precio > 0)
                    break;
                Console.WriteLine("Precio inválido. Debe ser un número positivo.");
            }

            Console.Write("Forma de pago (efectivo/tarjeta): ");
            string formaPago = Console.ReadLine().ToLower();

            if (formaPago == "tarjeta")
            {
                string numeroCuenta;
                while (true)
                {
                    Console.Write("Ingrese el número de cuenta (16 dígitos): ");
                    numeroCuenta = Console.ReadLine();
                    if (numeroCuenta.Length == 16 && long.TryParse(numeroCuenta, out _))
                        break;
                    Console.WriteLine("Número inválido. Debe tener 16 dígitos.");
                }
                Console.WriteLine($"Pago con tarjeta registrado: {numeroCuenta}");
            }
            else
            {
                Console.WriteLine("Pago en efectivo registrado.");
            }

            Console.WriteLine($"Precio del producto: {precio:C}");
            Console.WriteLine("Presione ENTER para salir...");
            Console.ReadLine();
        }
    }
}