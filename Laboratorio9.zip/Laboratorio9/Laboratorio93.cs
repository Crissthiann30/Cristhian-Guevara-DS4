using System;

namespace Laboratorio93
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Laboratorio93: Tipo de triángulo ===");

            double[] lados = new double[3];
            for (int i = 0; i < 3; i++)
            {
                while (true)
                {
                    Console.Write($"Ingrese lado {i + 1}: ");
                    if (double.TryParse(Console.ReadLine(), out lados[i]) && lados[i] > 0)
                        break;
                    Console.WriteLine("Valor inválido. Debe ser positivo.");
                }
            }

            Array.Sort(lados); // lados[2] es el mayor
            if (lados[0] + lados[1] <= lados[2])
            {
                Console.WriteLine("No se puede formar un triángulo.");
            }
            else
            {
                if (lados[0] == lados[1] && lados[1] == lados[2])
                    Console.WriteLine("Triángulo equilátero");
                else if (lados[0] == lados[1] || lados[1] == lados[2])
                    Console.WriteLine("Triángulo isósceles");
                else
                    Console.WriteLine("Triángulo escaleno");
            }

            Console.WriteLine("Presione ENTER para salir...");
            Console.ReadLine();
        }
    }
}